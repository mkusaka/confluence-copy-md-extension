chrome.action.onClicked.addListener(async e=>{if(e.id)try{await chrome.tabs.sendMessage(e.id,"COPY_CONFLUENCE_MD")}catch{}});
